version_number = '0.0.7'
document_revision = 'D'
release_date = '2020-12-9'

if __name__ == '__main__':
    print(version_number)
